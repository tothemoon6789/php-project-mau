<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminDanhmucCapmot extends Model
{
    //
}
